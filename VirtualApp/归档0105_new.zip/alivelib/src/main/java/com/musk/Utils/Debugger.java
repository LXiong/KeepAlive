package com.musk.Utils;

import android.util.Log;

/**
 * Created by musk on 17/12/28.
 */

public class Debugger {
    public static void i(String info){
        Log.i("musk","=="+info+"==");
    }
}
