package com.musk.Utils;

/**
 * Created by musk on 18/1/3.
 */

public class Config {
    public static final String alivePkgName="com.musk.assistant";
    public static final String aliveClassName="com.musk.assist.AssistService";
    public static final String aliveActName="com.musk.assist.AssistActivity";
    public static final String cacheDirName="/sdcard/cache/";
    public static final String cacheFileName="corelib.jar";

}